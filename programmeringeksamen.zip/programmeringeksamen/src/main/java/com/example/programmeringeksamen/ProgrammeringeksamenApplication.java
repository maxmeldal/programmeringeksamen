package com.example.programmeringeksamen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProgrammeringeksamenApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProgrammeringeksamenApplication.class, args);
    }

}
