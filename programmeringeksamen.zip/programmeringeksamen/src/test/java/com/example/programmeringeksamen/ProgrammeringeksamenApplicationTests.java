package com.example.programmeringeksamen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgrammeringeksamenApplicationTests {

    @Test
    void contextLoads() {
    }

}
